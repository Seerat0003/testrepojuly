/*:
## Exercise - Type Casting and Inspection

 Create a collection of type [Any], including a few doubles, integers, strings, and booleans within the collection. Print the contents of the collection.
 */
var array: [Any] = [5, 3, 1.4,"hello", "hi",true,true,false]
if let array1 = array[0] as? Double {
    print(array1)
}
if let array2 = array[1] as? Int {
    print(array2)
}
if let array3 = array[2] as? String {
    print(array3)
}
if let array4 = array[3] as? Bool {
    print(array4)
}

//:  Loop through the collection. For each integer, print "The integer has a value of ", followed by the integer value. Repeat the steps for doubles, strings and booleans.
for arr in array {
    if let arr = arr as? Int {
        print("The integer has a value of \(arr)")
    }
    if let arr = arr as? Bool {
        print("The Bool has a value of \(arr)")
    }
    if let arr = arr as? String {
        print("The String has a value of \(arr)")
    }
    if let arr = arr as? Double {
        print("The Double has a value of \(arr)")
    }
}

//:  Create a [String : Any] dictionary, where the values are a mixture of doubles, integers, strings, and booleans. Print the key/value pairs within the collection
var dictionary: [String: Any] = ["Name": "Seerat Sharma", "Age": 19, "Weight": 55.5, "In University?": true]
print(dictionary.keys)
print(dictionary.values)

//:  Create a variable `total` of type `Double` set to 0. Then loop through the dictionary, and add the value of each integer and double to your variable's value. For each string value, add 1 to the total. For each boolean, add 2 to the total if the boolean is `true`, or subtract 3 if it's `false`. Print the value of `total`.
var total: Double = 0
for name in dictionary.values {
    if let names = name as? Int {
        total += Double(names)
    }
    if let names = name as? Double {
        total += names
    }
    if let names = name as? String {
        total += 1
    }
    if let names = name as? Bool {
        if names == true {
            total += 2
        } else {
            total -= 3
        }
    }
}
print(total)

//:  Create a variable `total2` of type `Double` set to 0. Loop through the collection again, adding up all the integers and doubles. For each string that you come across during the loop, attempt to convert the string into a number, and add that value to the total. Ignore booleans. Print the total.
var total2: Double = 0
for add in dictionary.values {
    if let add = add as? Int {
        total2 += Double(add)
    }
    if let add = add as? Double {
        total2 += add
    }
    if let add = add as? String {
        total2 += Double(add.count)
    }
}
print(total2)

/*:
page 1 of 2  |  [Next: App Exercise - Workout Types](@next)
 */
